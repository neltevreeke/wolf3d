These WOLFletters(r) are
copyright(c) 1999 by Kurt Fankhauser 
Some of these WOLFletters(r) where created by other
people such as "who knows who" 